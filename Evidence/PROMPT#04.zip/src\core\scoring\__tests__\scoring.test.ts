import { describe, it, expect } from "vitest";
import { scoreLead } from "../scoreLead";
import { defaultScoringConfig } from "../config/defaultScoringConfig";
import type { LeadCompanyProfile } from "../../leads/types";

describe("Scoring Engine", () => {
  const mockLead: LeadCompanyProfile = {
    id: "1",
    name: "Acme Corp",
    domain: "acme.co.uk",
    website: "https://acme.co.uk",
    source_text: "Acme Corp is a lead candidate.",
    confidence: 0.9,
    method: "URL",
  };

  it("should identify UK region and award points", () => {
    const result = scoreLead(mockLead, defaultScoringConfig, "");
    expect(result.total).toBeGreaterThan(20);
    expect(result.signals.some((s) => s.id === "region-uk")).toBe(true);
  });

  it("should score high intent keywords", () => {
    const text = "I am looking for pricing and a demo of your product.";
    const result = scoreLead(mockLead, defaultScoringConfig, text);
    expect(result.signals.some((s) => s.id === "intent-high-pricing")).toBe(
      true,
    );
    expect(result.signals.some((s) => s.id === "intent-high-demo")).toBe(true);
    expect(result.intent).toBeGreaterThan(30);
  });

  it("should apply penalty for .gov domains", () => {
    const govLead: LeadCompanyProfile = { ...mockLead, domain: "nasa.gov" };
    const result = scoreLead(govLead, defaultScoringConfig, "");
    expect(result.signals.some((s) => s.id === "penalty-gov-edu")).toBe(true);
    expect(result.total).toBeLessThan(10); // Penalty should bring it down
  });

  it("should be deterministic", () => {
    const run1 = scoreLead(mockLead, defaultScoringConfig, "pricing");
    const run2 = scoreLead(mockLead, defaultScoringConfig, "pricing");
    expect(run1).toEqual(run2);
  });

  it("should handle empty input safely", () => {
    const emptyLead: LeadCompanyProfile = {
      id: "0",
      name: "",
      domain: "",
      source_text: "",
      confidence: 0,
      method: "BARE",
    };
    const result = scoreLead(emptyLead, defaultScoringConfig, "");
    expect(result.total).toBe(0);
    expect(result.signals).toHaveLength(0);
  });
});

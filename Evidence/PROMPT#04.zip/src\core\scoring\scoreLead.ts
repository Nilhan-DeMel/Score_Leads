import type { LeadCompanyProfile } from "../leads/types";
import type { ScoreBreakdown, ScoringConfig, ScoreSignal } from "./types";
import { scoreRegionFromDomain } from "./rules/scoreRegionFromDomain";
import { scoreKeywordIntentFromSourceText } from "./rules/scoreKeywordIntentFromSourceText";
import { scoreWebsitePresence } from "./rules/scoreWebsitePresence";
import { scoreEmailDomainPresence } from "./rules/scoreEmailDomainPresence";
import { scoreGovEduPenalty } from "./rules/scoreGovEduPenalty";
import { labelScore } from "./labelScore";

/**
 * Orchestrates scoring for a single lead.
 */
export function scoreLead(
  lead: LeadCompanyProfile,
  config: ScoringConfig,
  sourceText: string = "",
): ScoreBreakdown {
  const signals: ScoreSignal[] = [];
  const warnings: string[] = [];

  // 1. Run Rules
  const regionSignal = scoreRegionFromDomain(lead.domain);
  if (regionSignal) signals.push(regionSignal);

  const websiteSignal = scoreWebsitePresence(lead.website);
  if (websiteSignal) signals.push(websiteSignal);

  const domainSignal = scoreEmailDomainPresence(lead.domain);
  if (domainSignal) signals.push(domainSignal);

  const intentSignals = scoreKeywordIntentFromSourceText(sourceText, config);
  signals.push(...intentSignals);

  const penaltySignal = scoreGovEduPenalty(lead.domain);
  if (penaltySignal) signals.push(penaltySignal);

  // 2. Aggregate
  let fit = 0;
  let intent = 0;

  signals.forEach((s) => {
    if (
      s.id.startsWith("region") ||
      s.id.startsWith("presence") ||
      s.id.startsWith("penalty")
    ) {
      fit += s.points;
    } else if (s.id.startsWith("intent")) {
      intent += s.points;
    }
  });

  // Clamp Fit/Intent based on weights (simple normalization for v1)
  // Max fit points roughly: Region(20) + Website(10) + Domain(5) = 35.
  // We'll just sum them and clamp the final total to 100.

  const totalRaw = fit + intent;
  const total = Math.min(Math.max(totalRaw, 0), 100);

  return {
    total,
    fit,
    intent,
    signals,
    warnings,
    label: labelScore(total),
  };
}
